import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import { DEFAULT_SETTINGS, DEFAULT_TEXTS } from '../src/lib/defaults.js';

const prisma = new PrismaClient();

const img = (t: string, bg: string) =>
  `https://placehold.co/800x1000/${bg}/ffffff/png?text=${encodeURIComponent(t)}`;

async function main() {
  // Settings & texts: insert missing keys only (never overwrite admin edits)
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await prisma.setting.upsert({ where: { key }, update: {}, create: { key, value } });
  }
  for (const [key, v] of Object.entries(DEFAULT_TEXTS)) {
    await prisma.botText.upsert({ where: { key }, update: {}, create: { key, text: v.text, description: v.description } });
  }

  const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase().trim();
  if (!(await prisma.adminUser.findUnique({ where: { email } }))) {
    await prisma.adminUser.create({
      data: {
        email,
        name: 'Owner',
        role: 'OWNER',
        passwordHash: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10),
      },
    });
    console.log(`Admin created: ${email}`);
  }

  if ((await prisma.category.count()) > 0) {
    console.log('Catalog already seeded, skipping demo data.');
    return;
  }

  const cats = ['Lawn', 'Cotton', 'Chiffon', 'Linen', 'Formal', 'Wedding'];
  const catIds: Record<string, number> = {};
  for (const [i, name] of cats.entries()) {
    const c = await prisma.category.create({ data: { name, slug: name.toLowerCase(), sortOrder: i } });
    catIds[name] = c.id;
  }

  type Demo = {
    title: string; cat: string; fabric: string; pieces: number; stitching: 'STITCHED' | 'UNSTITCHED';
    occasion: string; tags: string; desc: string; bg: string; colorImgs?: [string, string][];
    variants: { color: string; size?: string; price: number; sale?: number; stock: number }[];
  };
  const sizes = ['S', 'M', 'L', 'XL'];
  const demo: Demo[] = [
    {
      title: 'Rose Lawn', cat: 'Lawn', fabric: 'Lawn', pieces: 3, stitching: 'STITCHED', occasion: 'Casual',
      tags: 'floral,summer,printed', bg: 'e85d8a', colorImgs: [['Pink', 'e85d8a'], ['Blue', '3b6fd6']],
      desc: 'Printed lawn shirt, dyed cambric trouser, chiffon dupatta. Light and breathable for summer.',
      variants: sizes.flatMap((s) => [
        { color: 'Pink', size: s, price: 6500, stock: s === 'XL' ? 0 : 5 },
        { color: 'Blue', size: s, price: 6500, sale: 5800, stock: 3 },
      ]),
    },
    {
      title: 'Mint Breeze Lawn', cat: 'Lawn', fabric: 'Lawn', pieces: 2, stitching: 'UNSTITCHED', occasion: 'Casual',
      tags: 'mint,green,summer,embroidered', bg: '3fb68b', colorImgs: [['Mint Green', '3fb68b'], ['Sky Blue', '5fb4e8']],
      desc: 'Unstitched embroidered lawn shirt (3m) with dyed trouser (2.5m).',
      variants: [
        { color: 'Mint Green', price: 4200, stock: 10 },
        { color: 'Sky Blue', price: 4200, stock: 6 },
      ],
    },
    {
      title: 'Ivory Chiffon Luxe', cat: 'Chiffon', fabric: 'Chiffon', pieces: 3, stitching: 'UNSTITCHED', occasion: 'Party',
      tags: 'embroidered,luxury,party,white', bg: 'b8a07e',
      desc: 'Embroidered chiffon front, sleeves and dupatta with raw silk trouser.',
      variants: [
        { color: 'Ivory', price: 14500, stock: 4 },
        { color: 'Black', price: 14500, stock: 2 },
      ],
    },
    {
      title: 'Classic Cotton Kurta', cat: 'Cotton', fabric: 'Cotton', pieces: 2, stitching: 'STITCHED', occasion: 'Casual',
      tags: 'daily wear,plain,office', bg: '5b7bd6',
      desc: 'Stitched cotton kurta with straight trouser. Perfect for office and daily wear.',
      variants: sizes.map((s) => ({ color: 'Navy Blue', size: s, price: 3900, stock: 4 })),
    },
    {
      title: 'Maroon Bridal Formal', cat: 'Wedding', fabric: 'Organza', pieces: 3, stitching: 'STITCHED', occasion: 'Wedding',
      tags: 'bridal,heavy,embroidered,red,maroon', bg: '8a1c2b',
      desc: 'Heavily embroidered organza shirt, jamawar trouser and net dupatta.',
      variants: ['S', 'M', 'L'].map((s) => ({ color: 'Maroon', size: s, price: 32000, stock: 1 })),
    },
  ];

  let skuN = 1000;
  for (const d of demo) {
    await prisma.product.create({
      data: {
        title: d.title, categoryId: catIds[d.cat], fabric: d.fabric, piecesCount: d.pieces,
        stitchingType: d.stitching, occasion: d.occasion, tags: d.tags, description: d.desc,
        code: d.title.toUpperCase().replace(/[^A-Z0-9]+/g, '-'),
        images: {
          create: [
            { url: img(d.title, d.bg), position: 0 },
            ...(d.colorImgs ?? []).map(([color, bg], i) => ({ url: img(`${d.title} - ${color}`, bg), color, position: i + 1 })),
          ],
        },
        variants: {
          create: d.variants.map((v) => ({
            sku: `SKU-${skuN++}`, color: v.color, size: v.size ?? null, price: v.price,
            salePrice: v.sale ?? null, stock: v.stock,
          })),
        },
      },
    });
  }

  const help = await prisma.customMenu.create({
    data: {
      title: 'Help & Info',
      body: 'What would you like to know?',
      buttonText: 'Help topics',
      items: {
        create: [
          { label: 'Size guide', description: 'Find your perfect fit', sortOrder: 0,
            action: 'TEXT:📏 *Size guide* (chest / length, inches)\nS: 36 / 40\nM: 38 / 41\nL: 40 / 42\nXL: 43 / 43' },
          { label: 'Delivery info', description: 'Charges & delivery time', sortOrder: 1,
            action: 'TEXT:🚚 Delivery in 3-5 working days all over Pakistan. PKR 250 delivery, free above PKR 10,000.' },
          { label: 'Exchange policy', description: 'Size & exchange', sortOrder: 2,
            action: 'TEXT:🔄 Exchange within 7 days if the item is unused with tags. Contact us with your order number.' },
          { label: 'My cart', description: 'See items in your cart', sortOrder: 3, action: 'CART' },
          { label: 'Talk to agent', description: 'Chat with our team', sortOrder: 4, action: 'HUMAN' },
        ],
      },
    },
  });

  await prisma.mainMenuItem.createMany({
    data: [
      { label: 'Browse Suits', action: 'BROWSE', sortOrder: 0, description: 'See our collections' },
      { label: 'Track Order', action: 'TRACK', sortOrder: 1, description: 'Check your order status' },
      { label: 'Help', action: `MENU:${help.id}`, sortOrder: 2, description: 'Sizes, delivery, agent' },
    ],
  });

  await prisma.autoReply.create({
    data: {
      keywords: 'shop address,location,outlet',
      response: 'We are an online store 🛍️ We deliver all over Pakistan with Cash on Delivery.',
      action: 'BROWSE',
    },
  });

  await prisma.knowledgeEntry.createMany({
    data: [
      { question: 'What is the delivery time and charge?', answer: 'Delivery takes 3-5 working days across Pakistan. Delivery charge is PKR 250, free on orders above PKR 10,000.', tags: 'delivery,shipping,charges' },
      { question: 'Do you offer Cash on Delivery?', answer: 'Yes, Cash on Delivery is available all over Pakistan.', tags: 'cod,payment' },
      { question: 'What is the exchange policy?', answer: 'Exchange within 7 days of delivery if unused with original tags. No cash refunds on sale items.', tags: 'return,exchange,refund' },
      { question: 'Size chart for stitched suits', answer: 'Chest/Length in inches: S 36/40, M 38/41, L 40/42, XL 43/43.', tags: 'size,chart,measurement,fit' },
      { question: 'How to wash lawn?', answer: 'Hand wash in cold water with mild detergent, dry in shade, iron on medium heat.', tags: 'care,wash,fabric' },
      { question: 'Do you do custom stitching?', answer: 'Custom stitching is not available online yet. Please talk to an agent for special requests.', tags: 'custom,tailoring,stitching' },
    ],
  });

  console.log('Demo catalog, menus and FAQ seeded.');
}

main().finally(() => prisma.$disconnect());
