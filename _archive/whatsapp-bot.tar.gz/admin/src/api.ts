const TOKEN_KEY = 'wa_admin_token';

export const auth = {
  get token() { try { return localStorage.getItem(TOKEN_KEY) ?? ''; } catch { return ''; } },
  set(t: string) { try { localStorage.setItem(TOKEN_KEY, t); } catch { /* ignore */ } },
  clear() { try { localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ } },
};

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(`/api${path}`, {
    method: opts.method ?? (opts.body ? 'POST' : 'GET'),
    headers: { 'Content-Type': 'application/json', ...(auth.token ? { Authorization: `Bearer ${auth.token}` } : {}) },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.startsWith('/auth/login')) {
    auth.clear();
    window.location.href = '/login';
  }
  if (!res.ok) throw new Error(json.error ?? `Error ${res.status}`);
  return json as T;
}

export async function uploadImage(file: File): Promise<string> {
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch('/api/upload', { method: 'POST', headers: { Authorization: `Bearer ${auth.token}` }, body: fd });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? 'Upload failed');
  return json.url;
}

export const fmt = (n: number) => `PKR ${Number(n || 0).toLocaleString('en-US')}`;
export const dt = (s: string) => new Date(s).toLocaleString();
