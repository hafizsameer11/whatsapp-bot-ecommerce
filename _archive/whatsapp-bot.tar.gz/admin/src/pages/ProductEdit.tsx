import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, uploadImage } from '../api';

type V = { id?: number; sku: string; color: string; size: string | null; price: number | ''; salePrice: number | '' | null; stock: number | ''; active: boolean };
const empty = {
  title: '', description: '', fabric: '', piecesCount: 3, stitchingType: 'UNSTITCHED', occasion: '', tags: '',
  status: 'DRAFT', categoryId: '' as number | '', images: [] as string[], variants: [] as V[],
};

export default function ProductEdit() {
  const { id } = useParams();
  const isNew = id === 'new';
  const nav = useNavigate();
  const [p, setP] = useState(empty);
  const [cats, setCats] = useState<any[]>([]);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState('');
  const [gen, setGen] = useState({ colors: '', sizes: 'S,M,L,XL', price: '', stock: '' });
  const [imgUrl, setImgUrl] = useState('');

  useEffect(() => {
    api('/categories').then(setCats);
    if (!isNew) api(`/products/${id}`).then((r) => setP({ ...r, images: r.images.map((i: any) => i.url) }));
  }, [id]);

  const set = (k: string, v: any) => setP((x) => ({ ...x, [k]: v }));
  const setV = (i: number, k: keyof V, v: any) => setP((x) => ({ ...x, variants: x.variants.map((r, j) => (j === i ? { ...r, [k]: v } : r)) }));
  const stitched = p.stitchingType === 'STITCHED';

  const generate = () => {
    const colors = gen.colors.split(',').map((s) => s.trim()).filter(Boolean);
    const sizes = stitched ? gen.sizes.split(',').map((s) => s.trim()).filter(Boolean) : [null];
    if (!colors.length) return setErr('Enter at least one colour to generate variants');
    const base = (p.title || 'SKU').toUpperCase().replace(/[^A-Z0-9]+/g, '').slice(0, 6);
    const existing = new Set(p.variants.map((v) => `${v.color}|${v.size ?? ''}`));
    const add: V[] = [];
    for (const c of colors) for (const s of sizes) {
      if (existing.has(`${c}|${s ?? ''}`)) continue;
      add.push({ sku: `${base}-${c.toUpperCase().replace(/[^A-Z0-9]+/g, '').slice(0, 5)}${s ? '-' + s.toUpperCase() : ''}`, color: c, size: s, price: Number(gen.price) || '', salePrice: '', stock: Number(gen.stock) || 0, active: true });
    }
    set('variants', [...p.variants, ...add]);
    setErr('');
  };

  const save = async () => {
    setErr(''); setMsg('');
    try {
      const body = { ...p, variants: p.variants.map((v) => ({ ...v, salePrice: v.salePrice || null })) };
      const r = isNew ? await api('/products', { body }) : await api(`/products/${id}`, { method: 'PUT', body });
      setMsg('Saved ✅');
      if (isNew) nav(`/products/${r.id}`, { replace: true });
      else api(`/products/${id}`).then((x) => setP({ ...x, images: x.images.map((i: any) => i.url) }));
    } catch (e: any) { setErr(e.message); }
  };
  const remove = async () => {
    if (!confirm('Delete this product? Past orders keep their own copy of item details.')) return;
    await api(`/products/${id}`, { method: 'DELETE' });
    nav('/products');
  };

  return (
    <>
      <div className="row spread">
        <h1>{isNew ? 'New product' : p.title}</h1>
        <div className="row">{!isNew && <button className="danger" onClick={remove}>Delete</button>}<button onClick={save}>Save</button></div>
      </div>
      {err && <div className="alert err">{err}</div>}
      {msg && <div className="alert ok">{msg}</div>}
      <div className="grid g2">
        <div className="card">
          <div className="field"><label>Title</label><input value={p.title} onChange={(e) => set('title', e.target.value)} /></div>
          <div className="field"><label>Description (shown on WhatsApp)</label><textarea value={p.description} onChange={(e) => set('description', e.target.value)} /></div>
          <div className="grid g3">
            <div className="field"><label>Category</label>
              <select value={p.categoryId} onChange={(e) => set('categoryId', Number(e.target.value))}>
                <option value="">Choose…</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select></div>
            <div className="field"><label>Stitching</label>
              <select value={p.stitchingType} onChange={(e) => set('stitchingType', e.target.value)}>
                <option value="UNSTITCHED">Unstitched</option><option value="STITCHED">Stitched (sizes)</option>
              </select></div>
            <div className="field"><label>Status</label>
              <select value={p.status} onChange={(e) => set('status', e.target.value)}>
                <option value="ACTIVE">Active (visible in bot)</option><option value="DRAFT">Draft</option><option value="HIDDEN">Hidden</option>
              </select></div>
            <div className="field"><label>Fabric</label><input value={p.fabric} onChange={(e) => set('fabric', e.target.value)} placeholder="Lawn" /></div>
            <div className="field"><label>Pieces</label><input type="number" value={p.piecesCount} onChange={(e) => set('piecesCount', Number(e.target.value))} /></div>
            <div className="field"><label>Occasion</label><input value={p.occasion} onChange={(e) => set('occasion', e.target.value)} placeholder="Casual / Party / Wedding" /></div>
          </div>
          <div className="field"><label>Search tags (comma separated, helps AI & keyword search)</label><input value={p.tags} onChange={(e) => set('tags', e.target.value)} placeholder="floral, summer, embroidered" /></div>
        </div>
        <div className="card">
          <h2>Images</h2>
          <p className="small muted">First image is used on product cards. JPG/PNG, max 5 MB. Uploaded images need PUBLIC_BASE_URL to be reachable by WhatsApp.</p>
          <div className="imgs">
            {p.images.map((u, i) => (
              <div className="im" key={u + i}><img src={u} alt="" />
                <button className="small danger" onClick={() => set('images', p.images.filter((_, j) => j !== i))}>×</button></div>
            ))}
          </div>
          <div className="row" style={{ marginTop: 10 }}>
            <input type="file" accept="image/png,image/jpeg" onChange={async (e) => {
              const f = e.target.files?.[0]; if (!f) return;
              try { set('images', [...p.images, await uploadImage(f)]); } catch (er: any) { setErr(er.message); }
              e.target.value = '';
            }} />
          </div>
          <div className="row" style={{ marginTop: 8 }}>
            <input placeholder="…or paste an image URL" value={imgUrl} onChange={(e) => setImgUrl(e.target.value)} style={{ flex: 1 }} />
            <button className="secondary" onClick={() => { if (imgUrl) { set('images', [...p.images, imgUrl]); setImgUrl(''); } }}>Add</button>
          </div>
        </div>
      </div>

      <div className="card">
        <h2>Variants (each = one SKU with its own stock)</h2>
        <div className="row" style={{ marginBottom: 12, background: '#f9fafb', padding: 10, borderRadius: 8 }}>
          <b className="small">Quick generate:</b>
          <input style={{ width: 200 }} placeholder="Colours: Pink, Blue" value={gen.colors} onChange={(e) => setGen({ ...gen, colors: e.target.value })} />
          {stitched && <input style={{ width: 140 }} placeholder="Sizes" value={gen.sizes} onChange={(e) => setGen({ ...gen, sizes: e.target.value })} />}
          <input style={{ width: 100 }} placeholder="Price" value={gen.price} onChange={(e) => setGen({ ...gen, price: e.target.value })} />
          <input style={{ width: 90 }} placeholder="Stock" value={gen.stock} onChange={(e) => setGen({ ...gen, stock: e.target.value })} />
          <button className="secondary small" onClick={generate}>Generate</button>
        </div>
        <table className="var-table">
          <thead><tr><th>SKU</th><th>Colour</th>{stitched && <th>Size</th>}<th>Price</th><th>Sale price</th><th>Stock</th><th>Active</th><th></th></tr></thead>
          <tbody>
            {p.variants.map((v, i) => (
              <tr key={i}>
                <td><input value={v.sku} onChange={(e) => setV(i, 'sku', e.target.value)} /></td>
                <td><input value={v.color} onChange={(e) => setV(i, 'color', e.target.value)} /></td>
                {stitched && <td><input value={v.size ?? ''} onChange={(e) => setV(i, 'size', e.target.value)} style={{ width: 60 }} /></td>}
                <td><input type="number" value={v.price} onChange={(e) => setV(i, 'price', e.target.value === '' ? '' : Number(e.target.value))} style={{ width: 100 }} /></td>
                <td><input type="number" value={v.salePrice ?? ''} onChange={(e) => setV(i, 'salePrice', e.target.value === '' ? '' : Number(e.target.value))} style={{ width: 100 }} /></td>
                <td><input type="number" value={v.stock} onChange={(e) => setV(i, 'stock', e.target.value === '' ? '' : Number(e.target.value))} style={{ width: 80 }} /></td>
                <td><input type="checkbox" checked={v.active} onChange={(e) => setV(i, 'active', e.target.checked)} /></td>
                <td><button className="small secondary" onClick={() => set('variants', p.variants.filter((_, j) => j !== i))}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="secondary small" style={{ marginTop: 8 }} onClick={() => set('variants', [...p.variants, { sku: '', color: '', size: stitched ? '' : null, price: '', salePrice: '', stock: 0, active: true }])}>+ Add variant</button>
      </div>
    </>
  );
}
